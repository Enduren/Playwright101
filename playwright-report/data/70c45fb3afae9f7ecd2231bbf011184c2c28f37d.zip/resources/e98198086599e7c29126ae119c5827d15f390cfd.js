$(function () {

    // Used to check name attribute without forcing case
    $.expr[':'].caseInsensitiveName = $.expr.createPseudo(function (value) {
        return function (elem) {
            return elem.getAttribute('name') == null ? false : elem.getAttribute('name').toLowerCase().indexOf(value.toLowerCase()) > -1;
        }
    });

    window.CompassCustomjsStartTime = new Date().getTime();

    whenUniqueAccountNumberFound(); // #19778 #21389

    hideCertainImprovementFormParts(); // #17172
    hideCertainImprovementViewParts(); //#21288
    adjustFieldsForSomeOldEquipChoices(); // #28023

    letQuantityDeterminSomeCustomFieldRanges(); // #17249
    // suppressStoreSizeFieldSometimes(); // stop doing this per #17954
    hideCertainBuildingFields(); // #17389 and #27161
    narrowDropdownOptions($('#buildingform #Address_State'), ['VA', 'NC']); // #17505
    itemNumberDeterminesAttributes(); // #20116
    //  adjustBuildingFormValidation(); //#17503 was reformed to limit validation to DQ testing -- maybe later we'll do form-level validation
    intializeCalcQaScore();  //for EditQA.aspx view
    hideCostColumn(); // #17580 
    hideExemptionStatusColumn(); // #18093  (Hide this column in pre-approval and rebate stage)
    hideCertainRebateFormFields(); // #17937 (#17927) 
    hideCertainBasicDataFields(); // #32718
    highlightPayee(); // #18409
    moveTechnicianField(); //#18618

    initLogIfNotAlready('measures-form-PSD-LOG', 500); // #18592 , limit persisted log to latest entries

    loadDataQualityMessages(); // #17870
    completeRebateImprovements();  //#17873

    deleteEmptyFieldSets();
    narrowDispositionReasons(); //#19005

    hideQaPackages(); //#19079

    measuresFormTimeout(); //#19684

    setPhoneAsRequired(); //#20608

    conditionalMeasureRequirements();  //#20844  (ref #18422 Technical Validation Process - DSM6 v4_1 20171003)

    blockFutureInstallDate();  //#21015

    QAResultMandatory();  //#21370

    hideMeasureFormData(); //#21372

    hideContactPerson(); //#45079

    showMeterDetails();

    populateContractorDetails();
    hideContractorGroup();

    enhanceWorkorderLink();

    hideImportWorkflowChoices();

    addBtnReportToPackageDetails(); //#25947 #31514 #32050

    RHEA_ImprovementStatusOptions();         //#26594  
    changeImprovementAndIncentiveHeaders();  //#26594

    alterRHEAMMPackageFields(); //#27160
    alterRHRFPackageFields(); //#31388, #31762
    alterRMHPPackageFields(); //#32052

    calculateSHGCDelta(); // #26884, #31029

    hideAssessmentDate(); // #28532
    hideAssessmentAnalyst();
    hideTotalInvoice(); // #32897

    readonlyMETotalInvoice(); // #28556, 36610, 41903

    hideBasicDataFieldsRTEE();  //#30054
    setConditionalFieldsRTEE(); //30060

    RTEE_AutoSelectCompleted(); // #30315

    RWEE_AutoSelectCompleted(); // #36191

    adjustFieldsForContractor(); //31442

    hideBasicDataFieldsRWEE(); //#36451, #36442
  
    validateTotalCost(); //#32749

    removeBasicDataAssessmentAnalyst(); //#34519

    swapPreviousWorkButtonURL(); //#40030

    addWarningTextToManager(); //#42753

    hideFieldsForCAFR();//47417
    $(function () {
        // NavBar/Building
        $('#addJob, #addJob-Nav').click(function () {
            if (!$('.launch-start-application-form-button').length) {
                const buildingId = $('#currentbldg').attr('data-id');

                const el = $('<div id="measures-form-apps"></div>');
                $('body').append(el);
                window.vueEventBus = window.initApplicationForm(el[0], {
                    base_url: '',
                    building_id: buildingId,
                    api_token: measureFormsApiToken,
                });
            }

            window.vueEventBus.$emit('launch-program-chooser');
            return false;
        })
            .removeAttr("href")
            .css('cursor', 'pointer');

        // Job Details Create Actual button
        $('a#jobComplete[href*="CreateActual"]').click(function () {
            if (!$('.launch-start-application-form-button').length) {
                const buildingId = $('#currentbldg').attr('data-id');
                var comparisonPackageUrl = $("#auditButton").attr('href'),
                    comparisonPackageUrlParts = comparisonPackageUrl.split("/");
                const comparisonPackageId = comparisonPackageUrlParts[comparisonPackageUrlParts.length - 1];

                var currentUrl = location.pathname;
                // Trim trailing / if exists in URL
                if (currentUrl.substring(currentUrl.length - 1) == '/')
                    currentUrl = currentUrl.slice(0, -1);

                var currentUrlParts = currentUrl.split("/");
                const jobId = currentUrlParts[currentUrlParts.length - 1];

                // Attempt to get comparisonJobName from navbar button
                var $navButton = $("a.item").filter(function () {
                    return $(this).prop('href').indexOf(currentUrl) != -1;
                })[0];

                const comparisonJobName = $($navButton).find(".content").text().trim().split(' ')[0].trim();

                // Get program from work order details
                var $programRow = $(".info-head").filter(function () {
                    return $(this).text().includes("Work Order Type");
                })[0];

                var programUnfiltered = $($programRow).next("td").text().trim();
                var programFilter = /-(.*)-/; // Everything between two hyphens
                const program = programFilter.exec(programUnfiltered)[1];
                const workflowName = programUnfiltered.match(/-(.*)/)[1];
                const el = $('<div id="measures-form-apps"></div>');
                $('body').append(el);
                window.vueEventBus = window.initApplicationForm(el[0], { 
                    base_url: '',
                    job_id: jobId,
                    building_id: buildingId,
                    program: program,
					workflow: {Name: workflowName},
                    comparison_package_id: comparisonPackageId,
                    comparison_job_name: comparisonJobName,
                    api_token: measureFormsApiToken,
                });
            }

            window.vueEventBus.$emit('launch-measures-form');
            return false;
        })
            .removeAttr("href")
            .css('cursor', 'pointer');

        // Import from external table search
        $('.addJob').click(function () {
            if (!$('.launch-start-application-form-button').length) {
                const buildingId = $(this).attr('data-buildingid');
                const state = $(this).attr('data-state');
                const key = $(this).attr('data-key');

                const el = $('<div id="measures-form-apps"></div>');
                $('body').append(el);
                window.vueEventBus = window.initApplicationForm(el[0], {
                    base_url: '',
                    building_id: buildingId,
                    state: state,
                    imported: newApplications[key],
                    api_token: measureFormsApiToken,
                });
            }

            window.vueEventBus.$emit('launch-program-chooser');
            return false;
        });
    });

});

function hideFieldsForCAFR() {

    // return if the BasicData element is not found
    if ($("#BasicData").length === 0) {
        return;
    }

    // return if we are not dealing with a CAFR job type
    if ($(".job-type-DVP-CAFR-VA").length === 0) {
        return;
    }
    // return if the CommercialDataPanel is the one that loaded
    if ($("span.whichView:contains('CommercialDataPanel')").length !== 0){
        return;
    }

    $('#proposed-audit-date').hide();
    $('#proposed-audit-time').hide();
    $('#proposed-contractor').hide();
    $('#proposed-auditor').hide();

    $('#proposed-incentives-total').show();
    $('#as-built-completed-incentives').show();
}
function addWarningTextToManager() {
    if ($("#contractor_view").length) {
        $("#contractor_view td.info-head").eq(8).siblings(":last").after("<td style='color:red'>DO NOT remove the Funding Source from this Contractor without reviewing their job listings. Verify that all workorders have been Completed, Cancelled or Deactivated. View Jobs button is located to the right.</td>")
    }

    if ($("#manager-form").length) {
        $("#fundingSourcesTable").parent().prepend("<p style='color:red'>DO NOT remove the Funding Source from this Contractor without reviewing their job listings. Verify that all workorders have been Completed, Cancelled or Deactivated. Cancel Edit and View Jobs button at top of prior UI.</p>");
    }
}

function swapPreviousWorkButtonURL() {
    var premiseIds = $(".addJob").map(function () {
        return { "key": $(this).attr("data-key"), "buildingId": $(this).attr("data-buildingid") };
    });

    for (var i = 0; i < premiseIds.length; i++) {
        $('a[href*="' + premiseIds[i].buildingId + '"]').attr("href", "/Jobs?PremiseID=" + newApplications[premiseIds[i].key]["DOM_P_PremiseID"]);
    }
}

function validateTotalCost() {
    if ($("#package-form").length > 0) {
        $("form").validate();
        $("#TotalCost").rules("add", {
            maxlength: 10
        });
    }
}

// Hide auditor for all commercial programs except CMFP/RMFP
function hideCertainBasicDataFields() {
    if ($("#commercial-auditor-selection").length > 0 && ($(".package-type-RMFPInitialAssessment").length < 1
        && $(".package-type-RMFPInstall").length < 1
        && $(".package-type-CMFPInstall").length < 1
        && $(".package-type-CMFPInitialAssessment").length < 1)) {
        $("#commercial-auditor-selection").hide();
    }
}

// Make DOM_P_METotalInvoice field disabled
function readonlyMETotalInvoice() {
    if ($("#package-form").length > 0 && (/(Add|Edit) COFF Rebate/.test($('h1').text())
        || /(Add|Edit) CBOT Rebate/.test($('h1').text())
        || /(Add|Edit) CBAS Rebate/.test($('h1').text())
        || /(Add|Edit) CSM Rebate/.test($('h1').text())
        || /(Add|Edit) CDATA Rebate/.test($('h1').text()))) {
        $("#Attribute_DOM_P_METotalInvoice").attr("readonly", "readonly");
    }
}

// Make Assessment Date not required for COFF/CSM/CNCR/CBOT IA, CEEP Rebate, CENG Enrollment
function hideAssessmentDate() {
    if ($("#package-form").length > 0
        && (/(Add|Edit) COFF Initial Assessment/.test($('h1').text())
            || /(Add|Edit) CSM Initial Assessment/.test($('h1').text())
            || /(Add|Edit) CEEP Rebate/.test($('h1').text())
            || /(Add|Edit) CBOT Initial Assessment/.test($('h1').text())
            || /(Add|Edit) CNCR Initial Assessment/.test($('h1').text())
            || /(Add|Edit) CENG Enrollment/.test($('h1').text())
            || /(Add|Edit) CDATA Initial Assessment/.test($('h1').text()))) {
        $("#Date").hide();
        $("label[for=Date]").hide();
    }

    // #36605, 36601
    if (($("#panelinner > h1:contains('CBOT Initial Assessment')").length !== 0) && $("#BasicData > h2:contains('Basic Data')").length !== 0) {
        var labels = [].filter.call(document.querySelectorAll('label'),
            function (e) {
                return e.textContent.includes('Assessment');
            });
        for (const element of labels) {
            if (element.innerText == 'Assessment Analyst:') {
                element.parentElement.style.display = "none";
            }
            if (element.innerText == 'Assessment Date:') {
                element.innerText = 'Audit Date';
            }
        }
       
       
        if (analyst.length > 0) {
            analyst[0].parentElement.style.display = "none";
        }
    }

    if (($("#panelinner > h1:contains('CEEP Rebate')").length !== 0 && $("#BasicData > h2:contains('Basic Data')").length !== 0)
        || ($("#panelinner > h1:contains('CENG Enrollment')").length !== 0 && $("#BasicData > h2:contains('Basic Data')").length !== 0)    ) {
        var elem = $('label:contains("Assessment Analyst")');
        elem.closest('li').hide();
        var elem = $('label:contains("Service Date")');
        elem.closest('li').hide();
    }
}

function hideAssessmentAnalyst() {
    if ((($("#panelinner > h1:contains('COFF Rebate')").length !== 0) || ($("#panelinner > h1:contains('CBOT Rebate')").length !== 0) || ($("#panelinner > h1:contains('CSM Rebate')").length !== 0) || ($("#panelinner > h1:contains('CNCR Rebate')").length !== 0) || ($("#panelinner > h1:contains('CDATA Rebate')").length !== 0) ) && $("#BasicData > h2:contains('Basic Data')").length !== 0) {
        var elem = $('label:contains("Assessment Analyst")');
        elem.closest('li').hide();
        $('#completedTotalCost').css("text-align", "left");
        $('.totalIncentives').css("text-align", "left");
    }
}


// Make Total Invoice not required for COFF/CSM IA, CBAS, CBOT, CENG
function hideTotalInvoice() {
    if ($("#package-form").length > 0
        && (/(Add|Edit) COFF Initial Assessment/.test($('h1').text())
            || /(Add|Edit) CSM Initial Assessment/.test($('h1').text())
            || /(Add|Edit) CBOT Initial Assessment/.test($('h1').text())
            || /(Add|Edit) CBAS Initial Assessment/.test($('h1').text())
            || /(Add|Edit) CENG Enrollment/.test($('h1').text())
            || /(Add|Edit) CDATA Initial Assessment/.test($('h1').text()))) {
        $("#TotalCost").hide();
        $("label[for=TotalCost]").hide();
    }
}

function adjustFieldsForSomeOldEquipChoices() { // per #28023

    const originalLabelsTargeted =
    {
        'Old Indoor Unit Make': 'Old Outdoor Unit Make'
        , 'Old Indoor Unit Model No': 'Old Outdoor Unit Model No'
        , 'Old Indoor Unit Fan': 'Old Outdoor Unit Fan'
        , 'Old Indoor Unit Serial No': 'Old Outdoor Unit Serial No' //added 
        , 'Old Outdoor Unit Make': null
        , 'Old Outdoor Unit Model No': null
        , 'Old Outdoor Unit Serial No': null
        , 'Old Fan Make': null
        , 'Old Fan Model No': null
        , 'Old Fan Serial No': null
    };
    const oldEquipToAdjust = ['AC: Single Packaged', 'HP: Single Packaged', 'CHILLER: Air cooled'];

    const improvementform = $('#improvementform')[0] || null;
    const improvementviewform = $('#improvementviewform')[0] || null;
    if (improvementform) {

        const collectedTargetFormFields = collectTargetFormFieldsByMeasureType(improvementform, originalLabelsTargeted);

        $('#ImprovementType').add('#Category').change(adjustFormFieldsForSelectedMeasureType);
        forOwnProperties(collectedTargetFormFields, (ob, u) => $(ob[u].oldEquipSelector).change(adjustFormFieldsForSelectedMeasureType));
        adjustFormFieldsForSelectedMeasureType();

        function adjustFormFieldsForSelectedMeasureType() {
            const selectedMeasureType = $('#ImprovementType').val();
            if (selectedMeasureType) /* sometimes it is triggered before measure type is set */
                adjustFormFields(collectedTargetFormFields[selectedMeasureType])
        }

    }
    if (improvementviewform) {//this branch should not be run twice, or you could hide fields you renamed before
        if (hasTrimmedTextChildAmong($('li.attr_UNIT_CATEGORY_OLD')[0], oldEquipToAdjust))
            queryAll(improvementviewform, 'li label')
                .map(node => ({ node, trimmedText: node.textContent.trim(), liNode: node.closest('li') }))
                .filter(({ node, trimmedText, liNode }) => originalLabelsTargeted.hasOwnProperty(trimmedText))
                .map(({ node, trimmedText, liNode }) => (node.textContent = originalLabelsTargeted[trimmedText]) || liNode.remove());
    }

    return;

    /* * * * * * * * *  the central function for updating form fields - can be applied repeatedly  * * * */
    function adjustFormFields({ targets, oldEquipSelector }) {
        targets.map(({ liNode, inputNode, adjustText, restoreText }) => {
            const oldEquip = (oldEquipSelector && oldEquipSelector.value) ? oldEquipSelector.value : null;
            const adjusting = oldEquipToAdjust.includes(oldEquip);
            const hiding = adjusting && !adjustText();
            if (!adjusting) restoreText();
            inputNode.disabled = hiding;
            if (hiding) liNode.classList.add('stayHidden'); // force hidden fields to stay hidden when improvement_functions.js runs
            liNode.style.display = hiding ? 'none' : 'block';
        })
    }

    function collectTargetFormFieldsByMeasureType(context, originalLabelsTargeted) {
        const res = {};
        allMeasureTypes(context).map(mid => {
            const zone = zoneForMeasureType(context, mid);
            const targetTextNodes = queryAll(zone, 'fieldset li label').map(el => arrayOfFirstTextChildWhere(el, text => originalLabelsTargeted.hasOwnProperty(text))).flat(1);
            const targets = targetTextNodes.map(textNode => {
                const originalText = textNode.textContent.trim();
                const liNode = textNode.parentNode.closest('li');
                const inputNode = liNode.querySelector('input');
                const adjustText = () => textNode.textContent = originalLabelsTargeted[originalText];
                const restoreText = () => textNode.textContent = originalText;
                return { liNode, inputNode, adjustText, restoreText }
            });
            res[mid] = { targets, oldEquipSelector: zone.querySelector(`select[name='Attribute_UNIT_CATEGORY_OLD']`) };
        });
        return res
    }

    function queryAll(context, sel) { return Array.from(context.querySelectorAll(sel)) }
    function forOwnProperties(ob, f) { for (let u in ob) if (ob.hasOwnProperty(u)) f(ob, u) }

    function allZones(context) { return queryAll(context, `div.attributesForImprovementType`) }
    function allMeasureTypes(context) { return allZones(context).map(zone => zone.id.replace(/^Attributes_(.*)$/, '$1')) }
    function zoneForMeasureType(context, mid) { return allZones(context).filter(el => el.id === `Attributes_${mid}`)[0] }

    function hasTrimmedTextChildAmong(el, texts) { return arrayOfFirstTextChildWhere(el, text => texts.includes(text)).length > 0 }
    function arrayOfFirstTextChildWhere(el, trimmedTextPred) {
        return Array.from(el.childNodes)
            .filter(node => node.nodeType === 3 && trimmedTextPred(node.textContent.trim()))
            .slice(0, 1)
    }

}


function calculateSHGCDelta() {
    if ($('#improvementform').length === 0) return;

    var fs = $('#fundingSource').text().trim();

    var preLabel; var postLabel; var impLabel;

    if (fs.includes("CWF2")) {
        preLabel = "Attribute_SHGC_Pre";
        postLabel = "Attribute_SHGC_Post";
        impLabel = "Attribute_SHGC_Improvement";
    }
    else if (fs.includes("SBI2")) {
        preLabel = "Attribute_SIZE3_OLD";
        postLabel = "Attribute_SIZE3_NEW";
        impLabel = "Attribute_WINDOW_FILM_SHGC_IMPROVEMENT";
    }
    else return;

    $("input[name='" + impLabel + "']").attr("readonly", true);

    function doSHGCDeltaCalc(pre, post) {
        if (pre == null || pre == ""
            || post == null || post == "")
            return 0;

        if (!$.isNumeric(pre) || !$.isNumeric(post))
            return 0;

        delta = parseFloat(pre) - parseFloat(post);
        delta = delta.toFixed(2);

        if (delta < 0)
            delta *= -1;

        return delta;
    }

    $("#" + preLabel + ", #" + postLabel).on("change", function () {
        var preVal = $("#" + preLabel).val();
        var postVal = $("#" + postLabel).val();

        var delta = doSHGCDeltaCalc(preVal, postVal);

        console.log(preVal + " " + postVal + " " + delta);

        if (delta == 0)
            $("#" + impLabel).val("");
        else
            $("#" + impLabel).val(delta);
    });

    $("#" + preLabel + ", #" + postLabel).change();
}

function alterRHEAMMPackageFields() {
    if ($(".package-type-RHEAMajorMeasureRebate").length) {
        // Hide Assessment Analyst field on RHEAMM
        $(".package-type-RHEAMajorMeasureRebate #AuditorID").parent().hide();

        // Update label Assessment Date -> Service Date
        $(".package-type-RHEAMajorMeasureRebate label[for='Date']").html("Service Date<span> *</span>");
        $(".package-type-RHEAMajorMeasureRebate #Date").attr("title", "<p>Enter the service date <b>(required)</b></p>");
    }
}

function alterRHRFPackageFields() {
    if ($(".package-type-RHRFAudit").length) {
        // Change Assessment Analyst to Audit Analyst
        $(".package-type-RHRFAudit label[for='AuditorID']").html("Audit Analyst");
        $(".package-type-RHRFAudit #AuditorID").attr("title", "<p>Choose the person who performed the Audit</p>");
        // Update label Assessment Date -> Audit Date
        $(".package-type-RHRFAudit label[for='Date']").html("Audit Date<span> *</span>");
        $(".package-type-RHRFAudit #Date").attr("title", "<p>Enter the audit date <b>(required)</b></p>");
    }
    else if ($(".package-type-RHRFMajorMeasureRebate").length) {
        // Hide Assessment Analyst field on RHEAMM
        $(".package-type-RHRFMajorMeasureRebate #AuditorID").parent().hide();

        // Update label Assessment Date -> Service Date
        $(".package-type-RHRFMajorMeasureRebate label[for='Date']").html("Service Date<span> *</span>");
        $(".package-type-RHRFMajorMeasureRebate #Date").attr("title", "<p>Enter the service date <b>(required)</b></p>");
    }
}

function alterRMHPPackageFields() {
    if ($(".package-type-RMHPAudit").length) {
        // Change Assessment Analyst to Audit Analyst
        $(".package-type-RMHPAudit label[for='AuditorID']").html("Audit Analyst");
        $(".package-type-RMHPAudit #AuditorID").attr("title", "<p>Choose the person who performed the Audit</p>");
        // Update label Assessment Date -> Audit Date
        $(".package-type-RMHPAudit label[for='Date']").html("Audit Date<span> *</span>");
        $(".package-type-RMHPAudit #Date").attr("title", "<p>Enter the audit date <b>(required)</b></p>");
    }
}

function addBtnReportToPackageDetails() {
    // This variable is found in CompassTemplates/Compass/Views/Packages/BasicDataPanel.cshmtl
    if (typeof canViewJobReports !== 'undefined' && canViewJobReports
        && /(RHEA Assessment|(RHRF|RMHP) Audit)/.test($('h1').text())) {
        var $btn = $("<a>").attr({
            href: '/Reports/HomeownerReport/' + reportJobId,
            class: 'c-btn c-btn-info',
            target: '_blank'
        }).append('<span class="icon-compass icon-compass-report"></span>&nbsp;&nbsp;Homeowner Report');

        /* Assume that the last table inside package-manage is the last part of the last "panel" on the page  */
        var anchor = $($('#package-manage table').last());

        anchor.after($btn);
        anchor.after('<h2>Work Order Reports</h2>');
    }
    if (typeof canViewJobReports !== 'undefined' && canViewJobReports
        && /(RVAU Rebate)/.test($('h1').text())) {
        var base_url = window.location.origin;
        var $btn = $("<a>").attr({
            href: base_url.replace(".buildingperformance", "-forms.buildingperformance") + '/psd/virtual-audit-report/v1/' + reportJobId,
            class: 'c-btn c-btn-info',
            target: '_blank'
        }).append('<span class="icon-compass icon-compass-report"></span>&nbsp;&nbsp;Virtual Audit Report');

        /* Assume that the last table inside package-manage is the last part of the last "panel" on the page  */
        var anchor = $($('#package-manage table').last());

        anchor.after($btn);
        anchor.after('<h2>Work Order Reports</h2>');
    }
}

function hideMeasureFormData() {
    if ($('#package-manage').length === 0) return;
    var measureFormData = $("fieldset:contains('Measures Form Data')");
    measureFormData.remove();

}

function QAResultMandatory() {
    var jq = $(".edit-qa-activity select[id$='Result']");
    if (jq.length === 0) return;
    var triggerElt = $("[id$='Status']");
    triggerElt.change(doit);
    doit();

    function doit() { (['24', '32'].indexOf(triggerElt.val()) < 0 ? makeNotRequired : makeRequired)($(".edit-qa-activity select[id$='Result']")); }
}

function hideContactPerson() {
    if ((/(Add|Edit) CDATA/.test($('h1').text()))) {
        $("#Attribute_DOM_P_mForm_ContactName").remove();
        $("label[for=Attribute_DOM_P_mForm_ContactName]").remove();
    }
}

var requirementFlag = '{required:true}';
function makeRequired(jq) {
    if (!jq.attr('required')) {
        jq.attr('required');
        jq.wrap('<span class="requiredField"/>');
        jq.after('<span style="font-size:large;"> *</span>');
    }
}
function makeNotRequired(jq, reqFlag, preserveLabel) {
    reqFlag = reqFlag || requirementFlag;
    preserveLabel = preserveLabel || false;
    if (jq.hasClass(reqFlag) || jq.attr('required')) {

        /* eliminate possible remnants of validation first */
        jq.removeClass('error');
        if (!preserveLabel) {
            $('label[for="' + jq.attr('id') + '"]').remove();
            /* undo makeRequired steps (reverse order) */
            jq.next('span').remove();
            jq.unwrap();
            if (jq.hasClass(reqFlag)) { jq.removeClass(reqFlag); }
            if (jq.attr('required')) { jq.removeAttr('required'); }

        }
        else {
            /* undo makeRequired steps (reverse order) */
            jq.prev('label').children('span').remove();
            jq.unwrap();
            if (jq.hasClass(reqFlag)) { jq.removeClass(reqFlag); }
            if (jq.attr('required')) { jq.removeAttr('required'); }
        }
    }
}
function setHtmlFromSelectionValue(jq) {
    var selVal = jq.val().trim();
    jq.find('option').removeAttr('selected');
    jq.find('option').map(function () {
        if ($(this).text().trim() === selVal)
            $(this)[0].setAttribute('selected', 'selected');
        else
            $(this).removeAttr('selected');
    });
}

function blockFutureInstallDate() {
    if ($("#panelinner > h1:contains('Edit Rebate')").length !== 0
        || $("#panelinner > h1:contains('Edit SBI2 Rebate')").length !== 0) {
        var thisElem = $('#Date');
        thisElem.addClass("nonFutureDate");
    }
    if ($("#panelinner > h1:contains('Account Verification')").length !== 0
        || $("#panelinner > h1:contains('SBI2 Account Verification')").length !== 0) {
        makeNotRequired($('#Date'), "{required:true, dateNoEarlierThan:'1/1/1901'}", true);
    }
}

function hideBasicDataFieldsRTEE() {
    if ($("#panelinner > h1:contains('Edit RTEE Rebate')").length !== 0 && $("#improvementform").length === 0) {
        var thisElem = $('#TotalCost');
        thisElem.closest('li').hide();
        thisElem = $('#AuditorID');
        thisElem.closest('li').hide();
        var label = $('#Date').prev('label[for="Date"]');
        var label_text = label.text();
        label.text(label_text.replace("Assessment Date", "Purchase Date"));
        $("form").validate();
        $("#Date").rules("add", "nonFutureDate");
    }

    if (($("#panelinner > h1:contains('RTEE Rebate')").length !== 0 || $("#panelinner > h1:contains('RTEE EFI Rebate')").length !== 0 || $("#panelinner > h1:contains('CEEP Rebate')").length !== 0) && $("#BasicData > h2:contains('Basic Data')").length !== 0) {
        var elem = $('label:contains("Assessment Analyst")');
        elem.closest('li').hide();
        var elem = $('label:contains("Test Out Time")');
        elem.closest('li').hide();
        elem = $('label:contains("Assessment Date")');
        elem.text("Purchase Date:");
    }

    function setAsRequired(item) {
        var item_attrId = item.attr('id');
        var item_label = item.prev('label[for="' + item_attrId + '"]');
        if (item_label.text().indexOf('*') < 0)
            item_label.append('<span>*</span>');

        $("form").validate();
        item.rules("add", "required");
    }
}

function setConditionalFieldsRTEE() {
    if ($("#panelinner > h1:contains('Edit RTEE Rebate')").length !== 0) {
        var heatingSystem = $('#Attribute_DOM_P_Online_Heating_System_Type');

        heatingSystem.change(function () {
            sethHeatingCoolingFields()
        });
    }

    function sethHeatingCoolingFields() {
        var selection = $('#Attribute_DOM_P_Online_Heating_System_Type  :selected').text();
        var heatingType = $('#Attribute_DOM_P_Heating_System_Type');
        var coolingType = $('#Attribute_DOM_P_Cooling_System_Type');
        switch (selection) {
            case "Heat Pump with Electric Emergency Heat":
            case "Heat Pump with Gas Backup":
                heatingType.val("Heat Pump: Air Source");
                coolingType.val("Heat Pump: Air Source");
                break;
            case "Ductless Mini Split Heat Pump":
                heatingType.val("Heat Pump: Ductless Mini Split");
                coolingType.val("Heat Pump: Ductless Mini Split")
                break;
            case "Geothermal Heat Pump":
                heatingType.val("Heat Pump: Geothermal");
                coolingType.val("Heat Pump: Geothermal");
                break;
            case "Other":
                heatingType.val("");
                coolingType.val("");
        }
    }
}

function conditionalMeasureRequirements() {
    if ($('#improvementform').length === 0) return;

    var fs = $('#fundingSource').text().trim();

    if (!fs.includes("CNRP") || !/(Add|Edit) Rebate Measure/.test($('h1').text()))
        return;

    var selectionTrigger = $(':caseInsensitiveName("attribute_ac_type")').add('#ImprovementType');

    selectionTrigger.change(function () {
        calcAcRequirements();
    });

    calcAcRequirements();

    function calcAcRequirements() {
        var improvementType = $('#ImprovementType  :selected').text();
        var acType = currentAttrSelectors().filter(':caseInsensitiveName("attribute_ac_type")').val();

        var COP = currentAttrInputs().filter(':caseInsensitiveName("attribute_cop")');
        var HSPF = currentAttrInputs().filter(':caseInsensitiveName("attribute_hspf")');
        var SEER = currentAttrInputs().filter(':caseInsensitiveName("attribute_seer")');
        var EER = currentAttrInputs().filter(':caseInsensitiveName("attribute_eer")');
        var chillerIPLV = currentAttrInputs().filter(':caseInsensitiveName("attribute_chiller_iplv_eer")');
        var chillerWaterSetPoint = currentAttrInputs().filter(':caseInsensitiveName("attribute_chiller_water_setpoint_f")');

        if (acType !== undefined && improvementType == 'AC Tune-Up') {
            if (acType.indexOf('Chiller') !== -1) {
                setAcRequirement(SEER, EER);
                setHeatRequirement(COP, HSPF);
                setChillerRequirement(chillerIPLV, chillerWaterSetPoint);
                validator.resetForm();
            }
            if (acType.indexOf('Unitary AC') !== -1) {
                clearChillerRequirement(chillerIPLV, chillerWaterSetPoint);
                clearHeatRequirement(COP, HSPF);
                setAcRequirement(SEER, EER);
                validator.resetForm();
            }
            if (acType.indexOf('Heat Pump') !== -1) {
                clearChillerRequirement(chillerIPLV, chillerWaterSetPoint);
                setAcRequirement(SEER, EER);
                setHeatRequirement(COP, HSPF);
                validator.resetForm();
            }
        }
        else if (acType !== undefined && improvementType == 'Duct Test & Seal') {
            if (acType.indexOf('Chiller') !== -1) {
                setAcRequirement(SEER, EER);
                setHeatRequirement(COP, HSPF);
                validator.resetForm();
            }
            if (acType.indexOf('Unitary AC') !== -1) {
                clearHeatRequirement(COP, HSPF);
                setAcRequirement(SEER, EER);
                validator.resetForm();
            }
            if (acType.indexOf('Heat Pump') !== -1) {
                setAcRequirement(SEER, EER);
                setHeatRequirement(COP, HSPF);
                validator.resetForm();
            }
        }

    }

    function setChillerRequirement(chillerIPLV, chillerWaterSetPoint) {
        setAsRequired(chillerIPLV);
        setAsRequired(chillerWaterSetPoint);
    }

    function clearChillerRequirement(chillerIPLV, chillerWaterSetPoint) {
        clearAsRequired(chillerIPLV);
        clearAsRequired(chillerWaterSetPoint);
    }

    function setAcRequirement(SEER, EER) {
        updateAcRequirement(SEER, EER);

        SEER.focusout(function (event) {
            updateAcRequirement(SEER, EER);
        });
        EER.focusout(function (event) {
            updateAcRequirement(EER, SEER);
        });
    }
    function updateAcRequirement(First, Second) {       //"first" and "second" param order to ensure the First(focus out) is set with *asterisk if it was last updated and contains a value
        var acType = currentAttrSelectors().filter(':caseInsensitiveName("attribute_ac_type")').val();
        if (acType.indexOf('Heat Pump') !== -1 || acType.indexOf('Chiller') !== -1) {
            if (First.val().trim().length != 0) {  //has value
                setAsRequired(First);
                clearAsRequired(Second);
            }
            else if (Second.val().trim().length != 0) {  //has value
                setAsRequired(Second);
                clearAsRequired(First);
            }
            else {
                setAsRequired(First);
                setAsRequired(Second);
            }
        }
        else {
            setAsRequired(First);
            setAsRequired(Second);
        }
    }
    function clearAcRequirement(SEER, EER) {
        clearAsRequired(EER);
        clearAsRequired(SEER);
    }

    function setHeatRequirement(COP, HSPF) {
        updateHeatRequirement(COP, HSPF);

        COP.focusout(function (event) {
            updateHeatRequirement(COP, HSPF)
        });
        HSPF.focusout(function (event) {
            updateHeatRequirement(HSPF, COP)
        });
    }

    function updateHeatRequirement(First, Second) {
        var acType = currentAttrSelectors().filter(':caseInsensitiveName("attribute_ac_type")').val();
        if (acType.indexOf('Chiller') !== -1)    //we only wanty COP for chillers
        {
            var COP = currentAttrInputs().filter(':caseInsensitiveName("attribute_cop")');
            var HSPF = currentAttrInputs().filter(':caseInsensitiveName("attribute_hspf")');
            setAsRequired(COP);
            clearAsRequired(HSPF);
        }
        else if (First.val().trim().length != 0) { //has value
            setAsRequired(First);
            clearAsRequired(Second);
        }
        else if (Second.val().trim().length != 0) {  //has value
            setAsRequired(Second);
            clearAsRequired(First);
        }
        else {
            setAsRequired(First);
            setAsRequired(Second);
        };
    }

    function clearHeatRequirement(COP, HSPF) {
        clearAsRequired(HSPF);
        clearAsRequired(COP);
    }

    function setAsRequired(item) {
        var item_attrId = item.attr('id');
        var item_label = item.prev('label[for="' + item_attrId + '"]');
        if (item_label.text().indexOf('*') < 0)
            item_label.append('<span>*</span>');

        item.rules("add", "required");
    }
    function clearAsRequired(item) {
        var item_attrId = item.attr('id');
        item.attr('class', '{number:true} valid');
        var item_label = item.prev('label[for="' + item_attrId + '"]');
        item_label.attr('class', '');
        item_label.removeAttr('required');
        var changedText = item_label.text().replace("*", "");

        //clean up for other weird text cases 
        changedText = changedText.replace("This field is required.", "");
        changedText = changedText.replace("This field is required.*", "");
        changedText = changedText.replace("Enter a valid number.", "");
        $('label[for="' + item_attrId + '"][generated=true]').remove();
        item_label.text(changedText);

        item.rules("remove", "required"); // KEY METHOD for a sticky validation error puzzle when using jQuery validation
    }
} //end of function conditionalMeasureRequirements()

function whenUniqueAccountNumberFound() {
    // only works on /ExternalTableImport/Search and /ExternalTableImport/Search/CustomerCoreAPIImportDirectors search results #38912
    if ($('form[action="/ExternalTableImport/Search"]').length === 0 &&
        $('form[action="/ExternalTableImport/Search/CustomerCoreAPIImportDirectors"]').length === 0) return;

    var acctNumRow = $('#responseArea').find('tr th:nth-child(1):contains("Account Number")').closest('tr');
    var acctNum = null;
    var acctNumCells = acctNumRow.find('td');
    if (acctNumRow.length === 1 && acctNumCells.length > 0) {
        acctNum = acctNumCells.first().text().trim();
        acctNumCells.each(function () { if ($(this).text().trim() !== acctNum) acctNum = null; }); // drop acctNum unless all cells agree
    }

    if (acctNum) { // now there is only one account number, though it might be in several columns
        if (!/^\d+$/.test(acctNum)) return; // block possible html injections from search form

        var jqConsumptionReceptacle = initReceptacle
            (function (x) { $('div#formArea').prepend(x); }
                , 'consumptionDisplayArea'
                , 'position: absolute; right:0; bottom:0;'
                , 'getting consumption data for ' + acctNum
            );

        function insertConsumptionTable(obj) {
            insertTableConsumption
                (obj
                    , useTableConsumption
                    , {
                        jqReceptacle: jqConsumptionReceptacle
                        , tableId: 'consumptionTable'
                        , tableCaptionId: 'consumptionTableCaption'
                        , tableScrollId: 'consumptionTableScroll'
                        , noneAvailableId: 'consumptionUnavailable'
                        , noneAvailableText: 'No records are available in range'
                        , cssText:
                            'td.consumption , th.consumption , #consumptionTableCaption , #consumptionUnavailable { padding: 3px; text-align: center;} '
                            + '#consumptionTable , #consumptionTableCaption {color: black; } '
                            + '#consumptionTable tr:nth-child(even) td , #consumptionTableCaption {background: rgb(231, 231, 231); } '
                            + '#consumptionTableScroll {max-height:180px; overflow-y:auto;} '
                            + '.ditto {opacity:0.5; font-size:smaller;} '
                            + '#consumptionUnavailable {font-style:italic;} '
                            + jqConsumptionReceptacle.selector + ' {outline:1px gray solid;} '
                    }
                );

            function useTableConsumption(table) {
                if (!(obj && obj.hasOwnProperty('Results'))
                    || !(obj.Results && obj.Results.hasOwnProperty('results'))) return; // api is not available;

                var rows = obj.Results.results;

                var columnsMap = {
                    "Meter ID": "MeterID",
                    "Start date": "StartDate",
                    "End date": "MRDate",
                    "Usage (kWh)": "Usage",
                    "Demand": "Demand",
                    "Amount": "TotalBilledAmount",
                    "Rate": "RateCode",
                    "Meter Status": "MeterStatus"
                };
                var columns = Object.keys(columnsMap);
                var colsHtml = "";
                columns.forEach(v => colsHtml += '<th class="consumption">' + v + '</th>');

                var rowsHtml = "";
                rows
                    .forEach(function (row) {
                        rowsHtml += "<tr>";
                        columns.forEach(function (c) {
                            val = row[columnsMap[c]];
                            if (columnsMap[c] == "MRDate" || columnsMap[c] == "StartDate") val = formatDate(new Date(val));
                            else if ($.isNumeric(val)) val = Number(val);
                            rowsHtml += '<td class="consumption ' + columnsMap[c] + '">' + val + '</td>';
                        });
                        rowsHtml += "</tr>";
                    });

                table.append(colsHtml)
                table.append(rowsHtml)
            }

            function useTable(table) {
                var accountColIndex = obj.cols.indexOf('Account');
                var meterColIndex = obj.cols.indexOf('Meter ID');
                var dateColIndex = obj.cols.indexOf('End date');
                var typeColIndex = obj.cols.indexOf('Usage type');
                var costColIndex = obj.cols.indexOf('Amount');

                var colsHtml = obj.cols.map(function (v, i) { return i === accountColIndex ? '' : '<th class="consumption">' + v + '</th>'; });
                table.append('<thead >' + colsHtml.join('') + '</thead>');
                var datedRows = obj.rows.map(function (row) { return { row: row, date: extractDateInt(row[dateColIndex]), meter: row[meterColIndex] }; });
                datedRows.sort(function (r1, r2) { // sort by reverse date then meter
                    return r2.date > r1.date
                        ? +1
                        : r2.date < r1.date
                            ? -1
                            : r1.meter > r2.meter
                                ? +1
                                : r1.meter < r2.meter
                                    ? -1
                                    : 0;
                });
                var meterOrder = [];
                datedRows.map(function (r) { if (meterOrder.indexOf(r.meter) < 0) meterOrder.push(r.meter) }); // latest meter first
                datedRows.sort(function (r1, r2) { // sort by meterOrder then reverse date
                    return meterOrder.indexOf(r1.meter) < meterOrder.indexOf(r2.meter)
                        ? -1
                        : meterOrder.indexOf(r1.meter) > meterOrder.indexOf(r2.meter)
                            ? +1
                            : r2.date - r1.date;
                });
                datedRows
                    .map(function (datedRow, k, drs) {
                        var cells = datedRow.row.map(function (v, i) {
                            var tdClasses = [];
                            var tooltip = null;
                            if (i === accountColIndex) return '';
                            var cellText = extractDateString(v) || v;
                            if (i === typeColIndex) cellText = { A: 'Active', F: 'Finaled', P: 'Pending final' }[v] || v;
                            if (i === costColIndex) cellText = '$' + v;
                            if ((i === meterColIndex || i === typeColIndex) && k > 0 && drs[k - 1].row[i] === v) {
                                tdClasses.push('ditto');
                                tooltip = 'same as in row above';
                            }
                            var titlePart = tooltip ? ('title="' + tooltip + '"') : '';
                            return '<td class="consumption ' + tdClasses.join(' ') + '" ' + titlePart + '>' + cellText + '</td>';
                        });
                        table.append('<tr class="consumption">' + cells.join('') + '</tr>');
                    });
            }
        }

        // get API token before calling getUsage
        $.ajax({
            type: 'POST',
            url: '/Account/GetToken',
            success: function (data, test, result) { getUsage(result, acctNum); },
            error: function () { alert('Failed to authenticate'); }
        });

        function getUsage(request, acctNum) {
            var authToken = request.getResponseHeader('Authorization');

            $.ajax({
                type: "GET"
                , url: '/api/DomAccount/' + acctNum + '/Usage'
                , async: true
                , dataType: "json"
                , success: insertConsumptionTable
                , error: function (jqXHR, textStatus) { jqConsumptionReceptacle.html('<i>Consumption API failed (' + textStatus + ')</i>'); }
                , beforeSend: function (req) { req.setRequestHeader('Authorization', 'Bearer ' + authToken); }
                , timeout: 20000
            });
        }

        var jqWODetailReceptacle = initReceptacle
            (function (x) { return $('div#responseArea').append(x); }
                , 'woDetailDisplayArea'
                , 'position: relative;'
                , 'getting Work Order Details for ' + acctNum
            );

        function insertWODetailTable(obj) {
            insertTable
                (obj
                    , function useTable(table) { obj.rows.map(function (r) { table.append('\n<tr><td>' + r[0] + '</td></tr>'); }); }
                    , {
                        jqReceptacle: jqWODetailReceptacle
                        , tableId: 'woDetailTable'
                        , tableCaptionId: 'woDetailTableCaption'
                        , tableScrollId: 'woDetailTableScroll'
                        , noneAvailableId: 'woDetailUnavailable'
                        , noneAvailableText: 'No Work Order detail is available'
                        , cssText:
                            'td.woDetail , th.woDetail , #woDetailTableCaption , #woDetailUnavailable { padding: 3px; text-align: center;} '
                            + '#woDetailTable , #woDetailTableCaption {color: black; } '
                            + '#woDetailTable tr:nth-child(even) td , #woDetailTableCaption {background: rgb(231, 231, 231); } '
                            + '#woDetailTable td {padding:5px;} '
                            + '#woDetailTable {width:100%;} '
                            + '#woDetailUnavailable {font-style:italic;} '
                            + jqWODetailReceptacle.selector + ' {outline:1px gray solid;} '
                    }
                );
        }

        $.ajax({
            type: "GET"
            , url: '/TableFetching/GetEm/' + acctNum + '?FetcherName=PriorTreatments'
            , async: true
            , dataType: "json"
            , success: insertWODetailTable
            , error: function (jqXHR, textStatus) { jqWODetailReceptacle.html('<i>Work Order Details API failed (' + textStatus + ')</i>'); }
            , timeout: 20000
        });
    }

    function insertTable(obj, useTable, _) {
        _.jqReceptacle.clear();
        if (!(obj && obj.hasOwnProperty('rows'))) return; // api is not available;
        else {
            _.jqReceptacle.append('<div id="' + _.tableCaptionId + '">' + (obj.remark || 'Account ' + acctNum) + '</div>');
            if (!(obj.rows && obj.rows.length > 0))
                _.jqReceptacle.append('<div id="' + _.noneAvailableId + '">' + _.noneAvailableText + '</div>');
            else {
                _.jqReceptacle.append('<div id="' + _.tableScrollId + '"><table id="' + _.tableId + '" class="customjs"></table></div>');
                useTable($('#' + _.tableId));
            }
            var jqStyle = initStyleFor(_.tableId);
            jqStyle.text(_.cssText);
        }
    }

    function insertTableConsumption(obj, useTable, _) {
        _.jqReceptacle.clear();
        if (!(obj && obj.hasOwnProperty('Results'))
            || !(obj.Results && obj.Results.hasOwnProperty('results'))) return; // api is not available;

        var results = obj.Results.results;
        _.jqReceptacle.append('<div id="' + _.tableCaptionId + '">' + (obj.remark || 'Account ' + acctNum) + '</div>');
        if (!(results && results.length > 0))
            _.jqReceptacle.append('<div id="' + _.noneAvailableId + '">' + _.noneAvailableText + '</div>');
        else {
            _.jqReceptacle.append('<div id="' + _.tableScrollId + '"><table id="' + _.tableId + '" class="customjs"></table></div>');
            useTable($('#' + _.tableId));
        }
        var jqStyle = initStyleFor(_.tableId);
        jqStyle.text(_.cssText);
    }

    function initReceptacle(jqContextualize, receptacleId, css, tooltip) {
        var jqReceptacle = $('#' + receptacleId);
        if (jqReceptacle.length === 0) {
            jqContextualize('<div id="' + receptacleId + '"/>');
            jqReceptacle = $('#' + receptacleId);
        }
        var jqReceptacleStyle = initStyleFor(receptacleId);
        jqReceptacleStyle.text('#' + receptacleId + ' {' + css + '}');
        var delayedAction = setTimeout(function () { //avoid the noise of spinner when request is answered quickly
            jqReceptacle.html('<img src="/Assets/ResImages/geco-button-with-spinner.gif"' + (tooltip ? 'title="' + tooltip + '"' : '') + '/>');
        }, 100);
        jqReceptacle.clear = function () { clearTimeout(delayedAction); jqReceptacle.children().remove(); };
        return jqReceptacle;
    }

    function initStyleFor(id) {
        var jqStyle = $('#style_for_' + id);
        if (jqStyle.length === 0) {
            $('body').prepend('<style id="style_for_' + id + '" class="customjs"/>');
            jqStyle = $('#style_for_' + id);
        }
        jqStyle.children().remove();
        return jqStyle;
    }

    function extractDateInt(v) {
        var m = /^\/Date\((\d*)\)\//.exec(v);
        return m && m[1] ? parseInt(m[1]) : null;
    }
    function extractDateString(v) {
        var n = extractDateInt(v);
        return n && dateStringFromInt(n);
    }
}

function dateStringFromInt(n) {
    var d = new Date(n);
    return (d.getMonth() + 1) + '/' + d.getDate() + '/' + d.getFullYear();
}

function formatDate(date) {
    return ((date.getMonth() > 8) ? (date.getMonth() + 1) : ('0' + (date.getMonth() + 1))) + '/' + ((date.getDate() > 9) ? date.getDate() : ('0' + date.getDate())) + '/' + date.getFullYear()
}

function setPhoneAsRequired() //on ManagerForm 
{
    if ($('#manager-form').length) {
        SetRequiredFields(["PhoneNumber"]);
        $('#PhoneNumber').attr('required', 'true');
        $('#PhoneNumber').attr('maxlength', '20');
    }
}

function itemNumberDeterminesAttributes() {

    var selectionTriggers = $(':caseInsensitiveName("attribute_itemno")').add('#ImprovementType');

    if (selectionTriggers.length === 0) return;

    //    $('body').append('<div id="loadingbox" style="position:fixed;top:50%;left:40%;"><b>Loading...</b><img src="/Assets/ResImages/ajax-loader.gif" alt="Loading" /></div>');
    //    jQuery('#loadingbox').show();

    var fs = $('#fundingSource').text().trim();

    if (fs.includes("CNRP") || fs.includes("SBI") || fs.includes("CLSC2") || fs.includes("CLT4") || fs.includes("CWF2") || fs.includes("CHCE2") || fs.includes("CNR2")) {
        var fstrimmed = fs;

        // Trim state from funding source
        if (fs.includes('-'))
            fstrimmed = fs.substring(0, fs.length - 3);

        $.get(`/Template/measures-form/${fstrimmed}Measures.json`, function (data) {
            var measures = data;
            selectionTriggers.change(updateCurrentAttributes);
            updateCurrentAttributes();

            function updateCurrentAttributes() {
                var improvementTypeId = $("#ImprovementType").val();
                var itemNumberValue = currentAttrSelectors().filter(':caseInsensitiveName("attribute_itemno")').val();
                var relevantAttrValues = itemMapping(itemNumberValue, measures, improvementTypeId);
                for (var u in relevantAttrValues) if (u !== 'itemNo' && relevantAttrValues.hasOwnProperty(u)) {
                    var attributeSelector = currentAttrSelectors().filter(':caseInsensitiveName("attribute_' + u + '")');
                    attributeSelector.children().remove();
                    attributeSelector.append('<option selected = "selected" value = "' + relevantAttrValues[u] + '">' + relevantAttrValues[u] + '</option>');
                    attributeSelector.change();
                }

            }

            //    	jQuery('#loadingbox').hide();
        });
    }
}

function currentAttrSelectors() {
    /*var attrTypes = window.attrTypesWithImprTypes.filter(function (x) { return x.imprType === $('#ImprovementType').val() }).map(function (x) { return x.attrType });
    function isAmongAttrTypes(x) {
        return (attrTypes.indexOf(x.replace('attr_', '')) >= 0);
    }*/

    var imprType = $('#ImprovementType  :selected').val();

    return $("#Attributes_" + imprType).find('li[id^="AttributeGroup_"]').children("select");
}

function currentAttrInputs() {
    /*var attrTypes = window.attrTypesWithImprTypes.filter(function (x) { return x.imprType === $('#ImprovementType').val() }).map(function (x) { return x.attrType });
    function isAmongAttrTypes(x) {
        return (attrTypes.indexOf(x.replace('attr_', '')) >= 0);
    }*/

    var imprType = $('#ImprovementType  :selected').val();

    return $("#Attributes_" + imprType).find('li[id^="AttributeGroup_"]').children("input");
}

measuresFormTimeout.formLifespanLimit_secs = (30 /* expected auto idle logout interval */ - 5 /* allow time for submission to complete once started */) * 60;
measuresFormTimeout.countdownDisplayFormBoundary_secs = 60;
function measuresFormTimeout() {
    var lifeSpanOverride = parseInt((/[\W]overrideMeasuresFormLifespan_secs=(\d+)/.exec(window.location.search) || { 1: "0" })[1]);
    var lifeSpan_secs = lifeSpanOverride || measuresFormTimeout.formLifespanLimit_secs;

    $('body').append('<div id="formCountdown" class="customjs" style=" display:none;" title="Time left to submit this form" ></div>');
    var countdown = $('#formCountdown');
    countdown.css({ color: 'white', textShadow: 'none', position: 'fixed', top: '5px', right: '5px', zIndex: 1060 });

    var launchButtons = $(".showMeasuresForm,a#addJob,a.addJob,a#addJob-Nav,a#jobComplete[href*='CreateActual']");
    launchButtons.click(function () {
        countdown.css('display', 'block');
    });
    keepAtIt();

    function keepAtIt() {
        var deadline = window.CompassCustomjsStartTime + 1000 * lifeSpan_secs;
        var now = new Date().getTime();
        var timeLeft = deadline - now;
        if (timeLeft <= 0) {
            countdown.remove();
            disableMeasuresForm();
        }
        else {
            var timeMsg = timeLeft > measuresFormTimeout.countdownDisplayFormBoundary_secs * 1000
                ? ('>' + Math.floor(timeLeft / 60000) + ' min')
                : (Math.floor(timeLeft / 1000) + ' sec');
            countdown.text(timeMsg);
            setTimeout(keepAtIt, 1000);
        }
    }

    function disableMeasuresForm() {
        var launchButtons = $(".showMeasuresForm,a#addJob,a.addJob,a#addJob-Nav,a#jobComplete[href*='CreateActual']");

        launchButtons.map(function () {
            var el = $(this)[0];
            var anchorText = el.innerHTML;
            el.classList.remove('showMeasuresForm');
            var classes = Array.from(el.classList).join(' ');
            var title = "Time limit for form submission expired. Reload page for new form";
            el.outerHTML = '<a style="background-color:#999999!important;color:#eeeeee;" class="' + classes + '" title="' + title + '" disabled="disabled">' + anchorText + '</a>';
            //el is a link like the one it replaces, but is dead, grey, and tooltipped about why and how-to-proceed
        });

        // Make sure modal still exists if we want to close it
        if ($('.modal button.close, .modal a.cancel').length)
            $('.modal button.close, .modal a.cancel')[0].click();
    }
}


function hideQaPackages() {  //Pre-Inspection view only
    if (document.getElementsByTagName("TITLE")[0].textContent.includes("Edit QA")) {
        if ($("#panelinner > h1:contains('Pre-Inspection')").length > 0)
            $("#qaPackages").hide();
    }
}

function deleteEmptyFieldSets() {
    $('fieldset')
        .filter(function () {
            return $(this).find('ol,table').length > 0 //we have a field set using lists or tables
                &&
                $(this).find('li,td').length === 0 // but it has no list items or table cells
                ;
        })
        .remove()
        ;
}

function initLogIfNotAlready(logKey, limit) {
    if (typeof limit === 'number' && (typeof localStorage[logKey] === 'undefined' || localStorage[logKey] === null))
        localStorage[logKey] = limit;
    addLogButton(logKey);
}

function showlog(logKey) {
    $('#logArea').remove();
    if (null === logKey) return /* null means just hide the log  */;
    var logObject = JSON.parse(localStorage[logKey]);
    var entries = logObject.entries || [];

    var body = $('body');

    body.append('<div id="logArea" class="customjs" '
        + 'style="outline:2px solid green;position:fixed;z-index:2000;left:5%;top:5%;padding:20px;width:90%;height:90%;background:white;"'
        + '><pre style="overflow:scroll;width:87%;height:87%;" /></div>');

    $('#logArea').prepend('<button id="hideLog">hide log</button> <button id="refreshLog">refresh</button> <br/>');
    $('#hideLog').click(function () { $('#logArea').remove(); });
    $('#refreshLog').click(function () { showlog(logKey); });

    var content = body.find('#logArea pre');
    entries.map(function (entry) { content.append('\n' + entry); });
    if (entries.length === 0) content.append('(nothing yet)');
}
function addLogButton(logKey) {
    $('#showLog').remove();
    if (localStorage[logKey]) {
        $('body').append('<span id="showLog" '
            + 'style="position:fixed;z-index:-1;bottom:2px;right:2px;opacity:0;cursor:default;">log</span>');
        $('#showLog')
            .click(function () { showlog($('#logArea').length === 0 ? logKey : null); })
            .hover(function () { $(this).animate({ opacity: 1 }, 1000); }, function () { $(this).css('opacity', 0).stop() });
    }
}

function highlightPayee() {

    var payeeElement = $('#BasicData #DynamicProperty_DOM_P_Payee');
    if (payeeElement.length === 0) return;

    var payee = ['Customer', 'Contractor'].filter(pay);
    if (payee.length === 0) return;

    if (payee[0] === 'Customer')
        payee = 'Mailing Address'; //label changed on the view page

    mapToView(payee);
    function mapToView(role) { var el = labelFor(role); el.prepend('<span style="color:red;" class="customjs">PAYEE </span>'); }
    function labelFor(role) { return $('td > label:contains("' + role + '")'); }
    function pay(role) { return payeeElement.find('td:contains("' + role + '")').text().trim() === role; }
}

function moveTechnicianField() {
    if ($("#package-manage").length) {
        var field = $('#BasicData #DynamicProperty_DOM_P_Technician');
        var name = field.text().replace("Technician Name:", "");
        name = name.replace("Technician Name*:", "");
        field.hide();
        $("#technician").html(name);
    }
}

function loadDataQualityMessages() {
    if ($('#package-manage').length) {
        var match = /Packages\/Manage\/([A-Fa-f0-9\-]{36})/.exec(window.location);
        if (match) {
            var packageId = match[1];
            var buildingId = $('#currentbldg').attr('data-id');

            function addHTML(x) { $('#package-manage').before(x); }

            var delayedAction = setTimeout(function () { //avoid the noise of spinner when request is answered quickly
                var tooltip = 'getting errors and warnings';
                addHTML('<img id="dqSpinner" src="/Assets/ResImages/geco-button-with-spinner.gif"' + (tooltip ? 'title="' + tooltip + '"' : '') + '/>');
            }, 200);

            var pending;
            function releaseSpinner() { pending--; if (pending < 1) { clearTimeout(delayedAction); $('#dqSpinner').remove(); } }
            function getFor(objectId) {
                var url = '/AnalysisTests/MessagesForScope/' + buildingId
                    + '?objectId=' + objectId
                    + '&eliminateDups=true' // #18914
                    + '&skipcache=' + (new Date().getTime()); // #18288 
                $.get(url, '', function (data) { addHTML(data); releaseSpinner(); });
            }
            var obIds = [buildingId, packageId];
            pending = obIds.length;
            obIds.map(getFor);
        }
    }
}

function hideCostColumn() {
    var imprTable = $('#package-manage #Improvements');
    if (!(imprTable.length > 0)) return;

    var headerCell = imprTable.find('td').filter(function () { return $(this).text().trim() === 'Cost' });
    var columnPosition = headerCell.index() + 1;

    imprTable.find('tbody > tr > td:nth-child(' + columnPosition + ')').remove();
}

function hideExemptionStatusColumn() {
    var incentiveTable = $('#package-manage #IncentiveList');
    var isPopulated = incentiveTable.length > 0;
    if (!isPopulated) return;

    var headerCell = incentiveTable.find('td').filter(function () { return $(this).text().trim() === 'Exemption Status' });
    var columnPosition = headerCell.index() + 1;

    incentiveTable.find('tbody > tr > td:nth-child(' + columnPosition + ')').remove();
}

function intializeCalcQaScore() {
    var QAScore = $("[id$='QAScore']");
    if (QAScore.length !== 0) {
        calcQaScore(QAScore);
        $('#qaPackages select').change(function () {
            calcQaScore(QAScore);
        });
    }
}

function calcQaScore(postQAScore) {
    var qaScore;
    var passCount = ($('#qaPackages select option:selected[value="Pass"]').length);
    var naCount = ($('#qaPackages select option:selected[value="NA"]').length);
    var failCount = ($('#qaPackages select option:selected[value="Fail"]').length);
    if ((passCount + naCount + failCount) !== 0)
        qaScore = ((passCount + naCount) / (passCount + naCount + failCount) * 100).toFixed(1);
    else qaScore = 0;
    (postQAScore.val(qaScore));
}

function completeRebateImprovements() {
    if ($("#improvementform").length > 0 && (/(Add|Edit) Rebate Measure/.test($('h1').text())
        || /(Add|Edit) RHEA Major Measure Rebate Measure/.test($('h1').text())
        || /(Add|Edit) CLSC2 Rebate Measure/.test($('h1').text())
        || /(Add|Edit) CLT4 Rebate Measure/.test($('h1').text())
        || /(Add|Edit) CWF2 Rebate Measure/.test($('h1').text())
        || /(Add|Edit) CHCE2 Rebate Measure/.test($('h1').text())
        || /(Add|Edit) SBI2 Rebate Measure/.test($('h1').text())
        || /(Add|Edit) CAFR Rebate Measure/.test($('h1').text())
        || /(Add|Edit) CNR2 Rebate Measure/.test($('h1').text()))) {
        $("#improvementform #InstalledState").val(1);
        $("#improvementform #InstalledState").closest("li").hide();
    }
}


function narrowDropdownOptions(elt, optionVals) {
    elt.find('option').each(function (i, e) { if (optionVals.indexOf($(e).val()) < 0) $(e).remove(); });
}


function narrowDispositionReasons() {
    // adjust the details page -- suppress Reason field if either it's "No reason required" or job (work order) status is Open
    var reasonDisplayElt = $('tr#DynamicProperty_DOM_J_DispositionReason');
    if (reasonDisplayElt.length > 0) {
        if (reasonDisplayElt.find("td:contains('No reason required')").length > 0
            ||
            $('td:contains("Work Order Status")').parent().find('td:contains("Open")').length > 0
        ) reasonDisplayElt.closest("fieldset").hide();
    }

    // adjust the form -- narrow dropdown to pertinent options, plus blank if there are more than one option ; 
    // preserve selection is valid ; hide dropdown if there's just one "option" ;
    // do this on page init and change of disposition selection
    var dispoElt = $('select#Status_Disposition_Id');
    var reasonsElt = $("select[id~='Attribute_DOM_J_DispositionReason']");
    if (dispoElt.length > 0 && reasonsElt.length > 0) {

        var allReasons = []; reasonsElt.find('option').each(function (i, e) { allReasons.push($(e).val()); }); // assume all reasons for all dispositions are passed into the view 

        function narrow() {
            var dispo = dispoElt.find('option:selected').text();
            var reasons = allReasons.filter(function (reason) { return reason.indexOf(dispo + ':') === 0; });
            if (reasons.length > 1) reasons.splice(0, 0, ""); // don't pre-select if there's a choice to be made
            narrowReasonsPerDisposition(dispo, reasonsElt, reasons);
            reasonsElt.closest('fieldset')[reasons.length === 1 ? "hide" : "show"]();
        }

        narrow();
        dispoElt.change(narrow);
    }

    function narrowReasonsPerDisposition(dispo, reasonsElt, reasons) {

        var alreadySelectedReason = reasonsElt.val() || "";
        reasonsElt.find('option').remove();
        reasons.map(function (reason) {
            reasonsElt.append('<option class="customjs" value="' + reason + '">' + reason.replace(new RegExp('^' + dispo + ':'), '') + '</option>');
        });
        reasonsElt.val(reasons.indexOf(alreadySelectedReason) >= 0 ? alreadySelectedReason : " ");
    }
}


function adjustBuildingFormValidation() {
    adjustValidation($('#buildingform #Address_Line1'), 50); //#17503 row 82 
    adjustValidation($('#buildingform #Address_City'), 40); //#17503 row 84
    adjustValidation($('#buildingform #Variant_HomeContactName'), 80); //#17503 row 93
    adjustValidation($('#buildingform #Variant_HomeEmail'), 80); //#17503 row 94
}

function adjustValidation(elt, maxlen) {
    if (elt.attr('class'))
        elt.attr('class', elt.attr('class').replace(/maxlength:\s*\d+/, 'maxlength:' + maxlen));
    if (elt.attr('maxlength'))
        elt.attr('maxlength', maxlen);
}

function hideCertainRebateFormFields() {
    if (/^Create Rebate/.test($('h1').text().trim())
        || /^Create CLSC2 Rebate/.test($('h1').text().trim())
        || /^Create CLT4 Rebate/.test($('h1').text().trim())
        || /^Create CWF2 Rebate/.test($('h1').text().trim())) {
        //act on the Create Rebate form
        $("#improvementform #InstalledState").val(1);
        $(withId('Date'))
            .add(withId('TotalCost'))
            .add(withId('AuditorID'))
            .add(withId('6a38644f-477c-466b-bb02-3b12f1e7d359_Attribute_DOM_P_DateReceived'))
            .closest('li').remove() //remove instead of hide to prevent validation from blocking saving
            ;
        $('#content-block > form > div.defaultform.attribute-set-edit').hide();  //#18103 Hide or remove Rebate Details from Create Rebate screen
        $(".package-type-CLSC2Rebate.package-create #saveAndContinue").hide();
        $(".package-type-CLT4Rebate.package-create #saveAndContinue").hide();
        $(".package-type-CWF2Rebate.package-create #saveAndContinue").hide();
    }
    function withId(x) { return '#package-form #' + x; }
}

/* apropriated from POTOMAC custom.js  - adopted the field list from Potomac for residential; kept the old field list from Dominion for commercial */
function hideCertainBuildingFields() {

    function hideFieldsFunc() {

        var buildingIsCommercial = 0 <= ['Commercial'].indexOf($('#buildingTypeForAnalysis').add('#formBuildingType').text().trim());
        var buildingIsMultifamily = 0 <= ['Multifamily'].indexOf($('#buildingTypeForAnalysis').add('#formBuildingType').text().trim());
        //detail or form

        function accumulateElements(findElt, keys) {
            return keys.length === 0 ? $() : accumulateElements(findElt, keys.slice(1)).add(findElt(keys[0]));
        }

        function burst(s) { return s.split(';').map(function (x) { return x.trim(); }).filter(x => x); }
        function cat(s, t) { return s + ' ; ' + t; }

        if ($('#building_view').length > 0) { //details view
            function info(x) { return 'div.building-details td:contains("' + x + '")'; }

            var detailsToHide;

            if (buildingIsCommercial)
                detailsToHide = "Year Built ; Floors Below Grade ; Gross floor area ; Building Sub-Type ; Number of Occupants ; Percentage Occupancy ; Floors Above Grade";
            //			else if (buildingIsMultifamily)
            //				detailsToHide = "Floors Below Grade ; Gross floor area ; Square Footage ; Household Income; Percentage Occupancy ; Contact ; Floors Above Grade";
            else
                detailsToHide = "Year Built ; Floors Below Grade ; Square Footage ; Gross floor area ; Occupants ; Household Income ; Hot Water Fuel ; Floors Above Grade";

            accumulateElements(info, burst(detailsToHide)).closest('tr').hide();
        }

        if ($('#buildingform').length > 0) { //form view
            function withId(x) { return '#buildingform #' + x; }

            var fieldsToRemove = "";
            var fieldsThatArentAsRequired = "";


            if (buildingIsCommercial)
                fieldsToRemove = "YearBuilt ; Variant_FloorsBelowGrade ; Variant_GrossSqFt ; SubType_Id ; Variant_FloorsAboveGrade";
            //			else if (buildingIsMultifamily)
            //				fieldsToRemove = "Variant_FloorsBelowGrade ; Variant_GrossSqFt ; Variant_HeatedAndCooledSqFt; Variant_FloorsAboveGrade ; Owner_HouseholdIncome; Variant_HomeContactName ; Variant_HomePhone ; Variant_HomeEmail ; PercentageOccupancy ; SubType_Id";
            else {
                fieldsToRemove = "Variant_FloorsAboveGrade ;Variant_FloorsBelowGrade ; Variant_GrossSqFt ; Variant_NumWorkers ; Owner_HouseholdIncome ; Variant_HotWaterFuel_Id ; YearBuilt ; Variant_HeatedAndCooledSqFt";
            }
            accumulateElements(withId, burst(fieldsToRemove)).closest('li').remove();

            setTimeout(function () {
                accumulateElements(withId, burst(fieldsThatArentAsRequired)).each(function () {
                    $(this).attr('class', '');
                    $(this).removeAttr('required');
                    $(this).closest('li').removeClass('requiredField');
                    $(this).prev('label').children('span').remove();
                });
            },
                0);

            $("#buildingform #inner-Edit-Bottom").remove();
            deleteEmptyFieldSets();
        }
    }

    if ($('#building_view').length > 0) //details view
        hideFieldsFunc();
    else if (typeof initBuildingForm !== 'undefined')
        initBuildingForm.finally = hideFieldsFunc;

}

function suppressStoreSizeFieldSometimes() {
    var buildingSubtypeName = $('#buildingSubtype').text().trim();
    var isRestaurant = /^Food Service/.test(buildingSubtypeName);
    var isConvenience = /Convenience/.test(buildingSubtypeName);

    var storeSizeElt = $('#attr_5907466c-7796-4be4-96a7-bd6eb2112b65'); //this element is used in measure forms
    if (isRestaurant || isConvenience) {
        storeSizeElt.val(isRestaurant ? '' : 'For Convenience Store or Small Grocery');
        storeSizeElt.closest('li').addClass('stayHidden').hide();
    }
}

function hideCertainImprovementFormParts() {
    var form = $('form[action^="/Improvements/"]');

    var hiddenFields = ['#NotesListItem', '#DetailedDescriptionListItem' // #17172 
        , '#TotalCostListItem' // #17940
    ];

    if ($("#improvementform").length > 0) {
        // Don't remove Improvement Total Cost for RTEE
        if (/(Add|Edit) RTEE Rebate Measure/.test($('h1').text())) {
            hiddenFields = hiddenFields.filter(x => x !== '#TotalCostListItem');
            $("#Cost").removeClass("{required:true, number:true, minElidingCommas:-99999999, maxElidingCommas:99999999}");
            $("#Cost").addClass("{required:true, number:true, minElidingCommas:0.01, maxElidingCommas:99999999}");
            $("#Cost").attr('required', 'true');
            $("#TotalCostListItem label").addClass("requiredField");
            $("#TotalCostListItem label").append("<span> *</span>");

        }
    }

    hiddenFields.map(function (s) { form.find(s).hide(); });
}

function hideCertainImprovementViewParts() {
    if ($('#improvementviewform').length === 0)
        return;
    $('#DetailedDescriptionListItem').hide();
    $('#NotesListItem').hide();
    $('#TotalCostListItem').hide();

}

function letQuantityDetermineCustomFieldRange(_) {
    var dropdownId = 'attr_' + _.impAttrId;
    var dropdown = $('#' + dropdownId);
    dropdown.closest('li').addClass('stayHidden').hide(); //this stayHidden css class tells improvement_functions.js to keep this item hidden
    setDropdownFromQuantity();
    $('#Quantity').change(setDropdownFromQuantity);

    function setDropdownFromQuantity() {
        var optionString = _.getOptionVal(parseFloat($('#Quantity').val())).toString();
        dropdown.val(optionString);
        if (dropdown.length > 0 && dropdown.val() !== optionString) { //the dropdown may not be there at all 
            alert('There may be a system configuration error (report this error code=' + dropdownId + ')');
            throw 'letQuantityDetermineCustomFieldRange failed to set option in ' + dropdownId + ': ' + optionString;
        }
    }
}

function letQuantityDeterminSomeCustomFieldRanges() {
    [{
        impAttrId: '1a5f048d-fcee-4680-a5fa-4d2de3476824'
        , getOptionVal: function (quantity) {
            return quantity < 12
                ? '< 12 Tons (< 135 kBtu/h)'
                : quantity >= 12
                    ? '>= 12 Tons (>= 135 kBtu/h)'
                    : ''
                ;
        }
    }
        , {
            impAttrId: '194fb49d-feac-4dc8-ab13-7ecebe1cf5d0'
        , getOptionVal: function (quantity) {
            return quantity <= 20
                ? '<= 20 Tons'
                : quantity >= 21
                    ? '>= 21 Tons'
                    : ''
                ;
        }
    }
    ].map(letQuantityDetermineCustomFieldRange);
}

// This must be taken from the measures form app.js
function itemMapping(itemNo, measures, improvementTypeId) {
    var xx = measures;
    var i = 0;
    while (i < xx.length) {
        var yy = xx[i].measures;
        var j = 0;
        var additional_fields = null;
        while (j < yy.length) {
            var zz = yy[j].items;
            var k = 0;

            while (k < zz.length) {
                // Match on improvement type if we can
                if (zz[k].hasOwnProperty("improvement_type")
                    && zz[k].improvement_type.toLowerCase() == improvementTypeId.toLowerCase()
                    && zz[k].item_no == itemNo) {
                    return (zz[k].additional_fields);
                }

                if (zz[k].item_no == itemNo) {
                    additional_fields = zz[k].additional_fields;
                }

                k++;
            }


            j++;
        }

        if (additional_fields)
            return additional_fields;

        i++;
    }
    return (null);
}

function showMeterDetails() {

    var lolMeters = $('#DynamicProperty_DOM_P_MeterIds');

    if (lolMeters.length) {
        var delayedAction = setTimeout(function () { //avoid the noise of spinner when request is answered quickly
            var tooltip = 'getting demand readings';
            if (pending) {
                lolMeters.parent().append('<tr id="demandSpinner"><td colspan="2"><img src="/Assets/ResImages/geco-button-with-spinner.gif"' + (tooltip ? 'title="' + tooltip + '"' : '') + '/></td></tr>');
            }
        }, 200);


        lolMeters.hide();
        var meterIds = lolMeters.children('td:nth-child(2)').text().split(",").map(function (x) { return x.trim() }).filter(function (x) { return x !== "" });
        var pending = meterIds.length;
        function releaseSpinner() { pending--; if (pending < 1) { clearTimeout(delayedAction); $('#demandSpinner').remove(); } }

        function insertIt(content) {
            lolMeters.parent().append('<tr class="customjs"><td colspan="2">' + content + '</td></tr>');
            releaseSpinner();
        }

        for (var i = 0; i < meterIds.length; ++i) {
            var url = '/Meters/MeterDetails/' + meterIds[i] + '?maxRowsPerMeter=13&orderByDescendingDate=true';
            $.get(url, '', function (data) { insertIt(data); });
        }
    }
}

function populateContractorDetails() {
    var lolDesignFirm = $('#DynamicProperty_DOM_P_DesignFirm');

    if (lolDesignFirm.length) {
        var delayedAction = setTimeout(function () { //avoid the noise of spinner when request is answered quickly
            var tooltip = 'getting demand readings';
            if (pending) {
                lolDesignFirm.parent().append('<tr id="demandSpinner"><td colspan="2"><img src="/Assets/ResImages/geco-button-with-spinner.gif"' + (tooltip ? 'title="' + tooltip + '"' : '') + '/></td></tr>');
            }
        }, 200);

        const adminLink = document.querySelector("#admin");
        if (!adminLink || adminLink.className !== "admin")
            lolDesignFirm.hide();

        var lolDesignFirmId = lolDesignFirm.children('td:nth-child(2)').text().split(",").map(function (x) { return x.trim() }).filter(function (x) { return x !== "" });
        var pending = lolDesignFirmId.length;
        function releaseSpinner() { pending--; if (pending < 1) { clearTimeout(delayedAction); $('#demandSpinner').remove(); } }

        $.ajax({
            type: 'POST',
            url: '/Account/GetToken',
            success: function (data, test, result) { showContractorDetails(result, lolDesignFirmId); },
            error: function () { alert('Failed to authenticate'); }
        });

        function showContractorDetails(request, lolDesignFirmId) {
            var authToken = request.getResponseHeader('Authorization');

            $.ajax({
                type: 'GET',
                url: '/api/serviceproviders/' + lolDesignFirmId[0],
                success: function (res) { insertIt(res); },
                error: function (req) { releaseSpinner(); },
                beforeSend: function (req) { req.setRequestHeader('Authorization', 'Bearer ' + authToken); }
            });

            function insertIt(content) {
                var namelink = $('#customerNameRow td:eq(7)').children('a');
                if (namelink.length) {
                    var url = namelink.attr('href');
                    comparisonPackageUrlParts = url.split("?");
                }
                var name = namelink.length ? `<a href="/Managers/Edit/` + lolDesignFirmId[0] + '?' + comparisonPackageUrlParts[comparisonPackageUrlParts.length - 1] + `">` + content.CompanyName + `</a>` : content.CompanyName;
                var address1 = content.Address.Line1 ? content.Address.Line1 : "";
                var address2 = content.Address.Line2 ? content.Address.Line2 : "";
                var city = content.Address.City ? content.Address.City : "";
                var state = content.Address.State ? content.Address.State : "";
                var zip = content.Address.Zip ? content.Address.Zip : "";
                var email = content.Email ? content.Email : "";
                var contactName = content.ContactName ? content.ContactName : "";
                var phone = content.PhoneNumber ? content.PhoneNumber : "";
                lolDesignFirm.parent().append(`<tr class="customjs"><td colspan="2"><table>
                                                <tr><td><label>Name:</label></td><td>` + name + `</td></tr>
                                                <tr><td><label>Address1:</label></td><td>` + address1 + `</td></tr>
                                                <tr><td><label>Address2:</label></td><td>` + address2 + `</td></tr>
                                                <tr><td><label>City:</label></td><td>`+ city + `</td></tr>
                                                <tr><td><label>State:</label></td><td>`+ state + `</td></tr>
                                                <tr><td><label>Zip:</label></td><td>`+ zip + `</td></tr>
                                                <tr><td><label>Contact Name:</label></td><td>`+ contactName + `</td></tr>
                                                <tr><td><label>Email:</label></td><td>`+ email + `</td></tr>
                                                <tr><td><label>Phone:</label></td><td>`+ phone + `</td></tr></table>
                                                </td></tr>`);
                releaseSpinner();
            }
        }
    }
}


function enhanceWorkorderLink() {

    var avWorkorder = $('#DynamicProperty_DOM_P_VerificationWorkorder');
    var avPackageId = $('#DynamicProperty_DOM_P_VerificationPackageID');

    if (avWorkorder.length) {
        var id = avPackageId.children('td:nth-child(2)').text();
        var wo = avWorkorder.children('td:nth-child(2)');
        wo.html('<a class="customjs" href="/Packages/Manage/' + id + '">' + wo.text() + '</a>');
        avPackageId.hide();
    }
}

function hideContractorGroup() {

    var group = $('#manager-form #contractor-group');
    var groupControl = group.find('select');
    $('<input type="hidden"></input>').val(groupControl.val()).appendTo(group);
    groupControl.remove();
    group.hide();//.find('label').hide();
}

function hideImportWorkflowChoices() {

    $("form[action*='Jobs/Create'] select#Workflow option").each(function (i, e) {
        if ($(e).text().includes("(Import)"))
            $(e).remove();
    });
}

function changeImprovementAndIncentiveHeaders() {  //#26594
    //Changing/removing certain headers for Incentives and Improvements panels
    $('#IncentiveList tbody tr.super-title td h4').text('All Possible Incentives');
    $('#TotalInstalledCostDisplay').remove();
}

function RHEA_ImprovementStatusOptions() {//#26594 #31300 #31302 #32053 #32057
    if ($("#improvementform").length > 0 &&
        (/(Add|Edit) (RHEA Assessment|(RHRF|RMHP) (Audit|Major Measure Rebate)|RMFP Initial Assessment) Measure/.test($('h1').text()))) {
        limitStatusOptionsForDirectInstalls();
        $('#Category').change(limitStatusOptionsForDirectInstalls);
    }
}

//#26594 - If a Direct Install improvement (not a Major Measure) is chosen, make 'Completed' the only option for the Installed State (Measure Status)
//#31300 #31302 - Applies to RHRF / RHRFMM Direct Install as well
//#32053 #32057 - RMHP / RMHPMM
function limitStatusOptionsForDirectInstalls() {
    var directInstalls = ["Efficient Faucet and Aerators", "Hot Water Appliances", "LED Bulbs", "Lighting", "Domestic Hot Water"];
    var statusElement = $('#InstalledState');
    if ($('h1').text().includes("Major Measure")) {
        statusElement.val('1');
        statusElement.children("option[value!='1'").hide();
        return;
    }
    var improvementCategory = $('#Category option:selected').text()
        .replace(" RHRFMM", "").replace(" RMHPMM", "").replace(" RHRF", "").replace(" RMHP", "");
    if (directInstalls.includes(improvementCategory)) {
        statusElement.val('1');
        statusElement.children("option[value!='1']").hide();
        statusElement.children("option[value!='0']").show();
    }
    else {
        statusElement.val('0');
        statusElement.children("option[value!='0']").hide();
        statusElement.children("option[value!='1']").show();
    }
}

function RTEE_AutoSelectCompleted() { // #30315 
    if ($("#improvementform").length > 0 && /(Add|Edit) RTEE Rebate Measure/.test($('h1').text())) {
        $("#InstalledState").val("1");
    }
}

function RWEE_AutoSelectCompleted() { // #36191 
    if ($("#improvementform").length > 0 && /(Add|Edit) RWEE Rebate Measure/.test($('h1').text())) {
        $("#InstalledState").children("option[value!='1']").hide();
        $("#InstalledState").val("1");
    }
}

// so any adjustments based on the contractor role can be grouped together
function adjustFieldsForContractor() {
    if (document.body.classList.contains("Contractor")) {
        disableContractorBuildingFields();
    }
}

function disableContractorBuildingFields() { //#31442
    if ($("#buildingform").length > 0) {
        $("#Name").closest('li').hide();
        $("#Address_Line1").closest('li').hide();
        $("#Address_City").closest('li').hide();
        $("#Address_State").closest('li').hide();
        $("#Address_Zip").closest('li').hide();
        $("#Variant_WeatherLocation_Id").closest('li').hide();
        $("#County_Id").closest('li').hide();
        $("#YearBuilt").closest('li').hide();
        $("#Variant_HeatedAndCooledSqFt").closest('li').hide();
        $("#Variant_FloorsAboveGrade").closest('li').hide();
    }
}

function removeBasicDataAssessmentAnalyst() {
    if (!($("#panelinner > h1:contains('Rebate')").length)) {
        return;
    }

    $("#basic-data li > label:contains(Assessment Analyst:)")
        .parent("li").remove();
}

function hideBasicDataFieldsRWEE() {
    if ($("#panelinner > h1:contains('RWEE Rebate')").length !== 0 && $("#BasicData > h2:contains('Basic Data')").length !== 0) {
        var cell = $("dt:contains('Assessment Analyst')");
        cell.hide();
        cell.next('dd').hide();
        var svcDate = $('dt:contains("Service Date")');
        svcDate.text("Install Date:");
        var lbl = $("label:contains('Assessment Date')");
        lbl.text("Install Date:");
    }

    if ($("#package-form").length > 0 && (/(Add|Edit) RWEE Rebate/.test($('h1').text()))) {
        var thisElem = $('#AuditorID');
        thisElem.closest('li').hide();
        var label = $('#Date').prev('label[for="Date"]');
        label.text("Install Date:");
        label.append('<span>*</span>');
        $('#Date').rules("add", "required");
    }
}