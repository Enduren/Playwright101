var href = "";
var countyList = "";
var counties = new Array();
var indexer = 0;

$(document).ready(function () {
    $("#ModelingType").change(function () {
        showOrHideAuditInfo();
    });
    showOrHideAuditInfo();

    $("#generateAPI").click(function () {
        $("#api_key").val(makeGuid());
    });
    if ($("#ChosenCounties").text() != "") {
        counties = $("#ChosenCounties").text().split(",\n");
    }
});

function addCounty(countyName) {
    var index = $.inArray(countyName, counties);
    if (index == -1) {
        //Value not found in the array.  Add to the end of the array with push();
        counties.push(countyName);
        $(this).css("foreground-color", "yellow");
    }
    else {
        //Remove from the array using splice(). Splice takes the index value of where you want to start 
        //removing items from the array as the first parameter, and then the number of item you want 
        //to remove as the second parameter.
        counties.splice(index, 1);
    }

    countyList = counties.join(',\n');
    $("#ChosenCounties").text(countyList);
};

function showOrHideAuditInfo() {
    if ($('#ModelingType option:selected').text() == 'Surveyor' || $('#modeltype').text() == 'Surveyor') {
        $('.auditInfo').hide();
        $('.auditInfoWarning').show();
    } else {
        $('.auditInfo').show();
        $('.auditInfoWarning').hide();
    }

    return true;
};

function makeGuid() {
    var hex = "0123456789ABCDEF";
    var guid = "";

    for (var cnt = 1; cnt <= 8; ++cnt) {
        var n = Math.floor(16384 * Math.random());
        for (var nibble = 1; nibble <= 4; ++nibble) {
            guid += hex.charAt(n & 0x0F);
            n >>= 4;
        }
        if (cnt > 1 && cnt < 6) guid += '-';
    }
    return guid;
}
