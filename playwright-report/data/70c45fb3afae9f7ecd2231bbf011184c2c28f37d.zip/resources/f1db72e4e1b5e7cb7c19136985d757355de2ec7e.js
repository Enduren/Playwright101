


$(document).ready(function () {
	pageOrSectionLoad();
});
function pageOrSectionLoad() {
	initializeTooltip();
	initializeAccordions();
};
function initializeTooltip() {
	$("#main [title]").tooltip(
                {
                	events: { input: 'mouseover focus, mouseleave blur' },
                	position: "center right",
                	effect: "fade",
                	fadeInSpeed: 100,
                	fadeOutSpeed: 50,
                	opacity: 0.9,
                	predelay: 250,
                	offset: [0, 8]
                });
	$('.hasErrorTooltip').tooltip();
	$("#main [hovertext]").attr("title", function () { return $(this).attr("hovertext"); });
        
};
function initializeAccordions() {
	$(".collapsedAccordion").accordion({ collapsible: true, active: 99 });
	$(".expandedAccordion").accordion({ collapsible: true, active: 0 });
};

function ajaxFormFailure(ajaxContext) {
    if (ajaxContext.get_response().get_statusCode() === 401) {
        location.reload();
    }

	$('#ajaxErrorBox').html('<p>Your request could not be completed.  Please try your request again.</p>');
	$('#ajaxErrorBoxContainer').show('fast', function () {
		setTimeout(function () { $('#ajaxErrorBoxContainer').hide('fast'); }, 5000);
	});
};