//
//  Validation Support
//
var validator;

$(document).ready(function () {

    //override defaults of jQueryValidate to keep same behavior as previous versions
    //swtich errorElement to span, newer versions default to <label>
    //add the "for" attribute to spans, newer versions only add it to <label>
    $.validator.setDefaults({
        errorElement: 'span',
        errorPlacement: function (error, element) {
            var idOrName = element.attr('id') || element.attr('name');
            var errorSpanId = error.attr('id');

            if (error) {

                if (idOrName) {
                    error.attr('for', idOrName);
                }

                if (errorSpanId) {
                    $('#' + errorSpanId).remove();
                }
                error.insertAfter(element);
            }
        },
        onkeyup: function (element, event) {
            // override keyup check to include 'element == this.lastActive'
            // without this check newer versions of jQuery Validate will check for errors after the user tabs out
            // when the user comes back to the field to fix the error it will then check as they type
            // adding 'element == this.lastActive' will make it so it always validates as the user types which is the old behavior
            var excludedKeys = [16, 17, 18, 20, 35, 36, 37, 38, 39, 40, 45, 144, 225];
            if (event.which === 9 && this.elementValue(element) === "" || $.inArray(event.keyCode, excludedKeys) !== -1) {
                return;
            } else if (element.name in this.submitted || element.name in this.invalid || element === this.lastActive) {
                this.element(element);
            }
        }
    });

    //overwrite default error messages for new version of jquery validate with the expected old ones
    $.extend($.validator.messages, {
        required: "This field is required.",
        remote: "Fix this field.",
        email: "Enter a valid email address.",
        url: "Enter a valid URL.",
        date: "Enter a valid date.",
        dateISO: "Enter a valid date (ISO).",
        number: "Enter a valid number.",
        digits: "Enter only digits.",
        equalTo: "Enter the same value again.",
        maxlength: $.validator.format("Enter no more than {0} characters."),
        minlength: $.validator.format("Enter at least {0} characters."),
        rangelength: $.validator.format("Enter a value between {0} and {1} characters long."),
        range: $.validator.format("Enter a value between {0} and {1}."),
        max: $.validator.format("Enter a value less than or equal to {0}."),
        min: $.validator.format("Enter a value greater than or equal to {0}.")
    });

    validator = $("form").validate();
    $.validator.addMethod("hasTheClass", function (value, element, param) { /* ignores the value - extracts a message from the class name provided as param */
        return this.optional(element) || element.classList.contains(param);
    }, function (param) { return (param.split('_').slice(1) || [param]).join(' '); });
    $.validator.addMethod("phone", function (ph, element) { // 10 is the minimum number of numbers required
        return this.optional(element) || ph !== null && /\d{10,}/i.test(ph.replace(/[\s()+-]|ext\.?/gi, ""));
    }, "Enter a valid phone number");
    $.validator.addMethod("notemptyguid", function (g, element) {
        return g !== null && g !== "00000000-0000-0000-0000-000000000000";
    }, "Select an option");
    $.validator.addMethod("integer", function (value, element) { // restriction of "number" validator excluding decimal point etc.
        return this.optional(element) || /^-?(?:\d+|\d{1,3}(?:,\d{3})+)$/.test(value);
    }, "Enter a whole number");
    $.validator.addMethod("pattern", function (value, element, param) {
        return this.optional(element) || new RegExp(param).test(value);
    }, "This value is not valid");
    $.validator.addMethod("minElidingCommas", function (value, element, param) {
        return this.optional(element) || value !== null && (new Number(value.replace(/,/g, ''))) >= param;;
    }, "Enter a value greater than or equal to {0}");
    $.validator.addMethod("maxElidingCommas", function (value, element, param) {
        return this.optional(element) || value !== null && (new Number(value.replace(/,/g, ''))) <= param;;
    }, "Enter a value less than or equal to {0}");
    $.validator.addMethod("nonFutureDate", function (value, element) {
        var thenEarlyEnough = false;
        var thenValid = !/Invalid|NaN/.test(new Date(value));
        if (thenValid) {//check date part only
            var then = new Date(value); then.setHours(0, 0, 0, 0);
            var now = new Date();
            thenEarlyEnough = then.getTime() <= now.getTime();
        }
        return this.optional(element) || thenEarlyEnough;
    }, "Enter a valid date not in the future");
    $.validator.addMethod("dateNoEarlierThan", function (value, element, param) {
        var lateEnough = false;
        var earliestValid = !/Invalid|NaN/.test(new Date(param));
        var enteredDateValid = !/Invalid|NaN/.test(new Date(value));
        if (earliestValid && enteredDateValid) {
            var enteredYear = /[^/]*$/.exec(value)[0];
            var enteredDate = new Date(value);
            if (enteredYear.length == 4) {
                enteredDate.setFullYear(enteredYear);
            }
            var earliest = new Date(param);
            lateEnough = earliest.getTime() <= enteredDate.getTime();
        }
        return this.optional(element) || lateEnough;
    }, "Enter a date no earlier than the date {0}");
    $.validator.addMethod("depends", function (value, element, param) {
        if (typeof param === "string") {
            param = JSON.parse(param.replace(/'/g, '"').replace(/([\{,])([A-z]+):/g, '$1"$2":'))
        }
        var required = checkRequiredness(element, param);

        if (required.length == param.length)
            if ($(element).val() == null || $(element).val() == "")
                return false;

        return true;
    }, "This field is required.");
    $.validator.addMethod("noOnlyWhiteSpace", function (value, element) {
        return !(value.length > 0 && value.replace(/\s/g, '').length == 0);
    }, "Remove whitespace.");
    $.validator.addClassRules("noSpace", { noOnlyWhiteSpace: true });

    GetDependentFields();
});

function checkRequiredness(element, param) {
    var required = [];

    // Loop through each condition, all conditions must be met to add requiredness
    param.forEach(function (condition) {
        var fieldValue;

        // If we find #, this is a core field
        if (condition.Name.includes("#")) {
            fieldValue = $(condition.Name).val();

        } else {
            fieldValue = $(element).parent().siblings().children("#Attribute_" + condition.Name).val();
        }

        // If we find an empty value don't do any comparisons
        if (fieldValue === null || fieldValue === "")
            return;

        switch (condition.Operator) {
            case "=":
                // We use pipe | to check or conditions
                var orConditions = condition.Value.split('|');

                for (var i = 0; i < orConditions.length; i++) {
                    // Once we find a matching condition then use as cause for requiredness
                    if (fieldValue === orConditions[i]) {
                        required.push(true);
                        break;
                    }
                }

                break;
            case ">":
                if (Number(fieldValue) > Number(condition.Value))
                    required.push(true);
                break;
            case "<":
                if (Number(fieldValue) < Number(condition.Value))
                    required.push(true);
                break;
            case ">=":
                if (Number(fieldValue) >= Number(condition.Value))
                    required.push(true);
                break;
            case "<=":
                if (Number(fieldValue) <= Number(condition.Value))
                    required.push(true);
                break;
            case "<>":
                if (fieldValue != condition.Value)
                    required.push(true);
            default:
                break;
        }
    });

    return required;
}

function GetDependentFields() {
    $('[data-dependson]').each(function () {
        var element = $(this);
        var dependsOn = element.data("dependson").split(',');

        dependsOn.forEach(function (depends) {
            var elementId = depends.includes("#") ? depends : "#Attribute_" + depends;

            $("form").on("change", elementId, function () {

                if (!element.is(":disabled")) {
                    var rules = element.rules();
                    // convert back to an object if rules is returned as a string
                    if (typeof rules.depends === "string") {
                        rules.depends = JSON.parse(rules.depends.replace(/'/g, '"').replace(/([\{,])([A-z]+):/g, '$1"$2":'))
                    }
                    var required = checkRequiredness(element, rules.depends);
                    var label = element.siblings("label")[0];
                    var span = $("<span> *</span>");

                    // When this is true, this field is required
                    if (required.length == rules.depends.length) {
                        $(label).addClass("requiredField");
                        if ($(label).has("span").length == 0)
                            $(label).append(span);
                    } else {
                        $(label).removeClass("requiredField");
                        $(label).find("span").each(function (index) {
                            $(this).remove();
                        });
                    }
                }
            });

            $(elementId).change();
        });
    });
}

function SetRequiredFields(fields) {
    $.each(fields, function (i, f) {
        var id = '#' + f.replace(/\./gi, '_');
        var field = $(id);
        if (field !== undefined) {
            field.addClass('required');
            var parent = field.parent();
            if (parent !== undefined) {
                parent.addClass('requiredField');
            }
            var label = $('label[for="' + f.replace(/\./gi, '_') + '"]');
            if (label !== undefined) {
                label.append('<span> *</span');
            }
        }
    });
}

function HideHiddenFields(fields) {
    $.each(fields, function (i, f) {
        var id = '#' + f.replace(/\./gi, '_');
        var field = $(id);
        if (field !== undefined) {
            var parent = field.parent();
            if (parent !== undefined) {
                parent.css('display', 'none');
            }
        }
    });
}
